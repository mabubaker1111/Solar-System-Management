
<?php $__env->startSection('title', 'Browse Businesses'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="fw-bold mb-4">Available Businesses</h3>

<div class="row">
<?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column">
                <h5 class="fw-bold">Name: <?php echo e($b->business_name); ?></h5>
                <p class="mt-2 text-muted">Description: <?php echo e(Str::limit($b->description,70)); ?></p>
                <p class="mt-0 text-muted">Location: <?php echo e(Str::limit($b->address,70)); ?></p>
                <div class="mt-auto">
                    <a href="<?php echo e(route('client.business.details', $b->id)); ?>" class="btn btn-outline-primary btn-sm w-100">View Details</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/client/businesses.blade.php ENDPATH**/ ?>