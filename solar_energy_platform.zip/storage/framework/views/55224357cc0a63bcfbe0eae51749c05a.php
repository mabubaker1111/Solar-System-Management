<!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Login</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <select id="loginRoleSelect" class="form-select mb-3">
                    <option value="client" selected>Client</option>
                    <option value="worker">Worker</option>
                    <option value="business">Business</option>
                </select>

                <div id="clientLoginForm">
                    <?php echo $__env->make('client.auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div id="workerLoginForm" style="display:none;">
                    <?php echo $__env->make('worker.auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div id="businessLoginForm" style="display:none;">
                    <?php echo $__env->make('business.auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Register Modal -->
<div class="modal fade" id="registerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Register</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                
                <select id="registerRoleSelect" class="form-select mb-3">
                    <option value="client" selected>Client</option>
                    <option value="worker">Worker</option>
                    <option value="business">Business</option>
                </select>

                <div id="clientRegisterForm"><?php echo $__env->make('client.auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div id="workerRegisterForm" style="display:none;"><?php echo $__env->make('worker.auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div id="businessRegisterForm" style="display:none;"><?php echo $__env->make('business.auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            </div>
        </div>
    </div>
</div>

<script>
    // Login Form Switch
    const loginSelect = document.getElementById('loginRoleSelect');
    const clientLogin = document.getElementById('clientLoginForm');
    const workerLogin = document.getElementById('workerLoginForm');
    const businessLogin = document.getElementById('businessLoginForm');

    loginSelect.addEventListener('change', function() {
        clientLogin.style.display = this.value === 'client' ? 'block' : 'none';
        workerLogin.style.display = this.value === 'worker' ? 'block' : 'none';
        businessLogin.style.display = this.value === 'business' ? 'block' : 'none';
    });

    // Register Form Switch
    const registerSelect = document.getElementById('registerRoleSelect');
    const clientRegister = document.getElementById('clientRegisterForm');
    const workerRegister = document.getElementById('workerRegisterForm');
    const businessRegister = document.getElementById('businessRegisterForm');

    registerSelect.addEventListener('change', function() {
        clientRegister.style.display = this.value === 'client' ? 'block' : 'none';
        workerRegister.style.display = this.value === 'worker' ? 'block' : 'none';
        businessRegister.style.display = this.value === 'business' ? 'block' : 'none';
    });
</script><?php /**PATH E:\solar_energy_platform\resources\views/frontend/partials/login_register_modals.blade.php ENDPATH**/ ?>