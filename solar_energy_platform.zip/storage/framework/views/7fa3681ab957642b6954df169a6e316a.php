
<?php $__env->startSection('title','Workers List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-4 fw-bold">Workers in Your Business</h3>

    <?php if($workers->count() == 0): ?>
    <div class="alert alert-warning">No workers assigned yet.</div>
    <?php else: ?>
    <div class="row">
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card worker-card shadow-lg border-0">
                <div class="card-body text-center p-4">

                    <div class="profile-img-wrapper mb-3">
                        <img src="<?php echo e($worker->photo ? asset('storage/'.$worker->photo) : 'https://via.placeholder.com/150'); ?>"
                            alt="Worker Photo" class="img-fluid rounded-circle profile-img">
                    </div>

                    <h5 class="worker-name mb-1"><?php echo e($worker->user->name ?? 'N/A'); ?></h5>
                    <p class="text-muted mb-2"><?php echo e($worker->skill ?? 'N/A'); ?></p>

                    <p class="worker-info">
                        <strong>Experience:</strong> <?php echo e($worker->experience ?? 'N/A'); ?> years
                    </p>

                    <p class="worker-status">
                        <strong>Status:</strong>
                        <span class="badge px-3 py-2 
                    <?php echo e($worker->status == 'approved' ? 'bg-success' : 'bg-warning'); ?>">
                            <?php echo e(ucfirst($worker->status)); ?>

                        </span>
                    </p>

                </div>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>
<style>
    /* Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

    .worker-card {
        border-radius: 18px;
        transition: all 0.3s ease;
        background: #ffffff;
        border-block-color: 
        font-family: 'Poppins', sans-serif;
    }

    .worker-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.15);
    }

    .profile-img-wrapper {
        width: 130px;
        height: 130px;
        margin: auto;
        border-radius: 50%;
        padding: 5px;
        background: linear-gradient(45deg, #4e98e7, #19e9b8);
    }

    .profile-img {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid #fff;
    }

    .worker-name {
        font-weight: 600;
        font-size: 20px;
        color: #333;
    }

    .worker-info {
        font-size: 15px;
        color: #555;
        margin-bottom: 10px;
    }

    .badge {
        font-size: 13px;
        border-radius: 12px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('business.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/business/workers.blade.php ENDPATH**/ ?>