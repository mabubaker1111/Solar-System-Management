<form method="POST" action="<?php echo e(route('worker.register.submit')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="mb-3">
        <label class="form-label">Name</label>
        <input type="text" class="form-control" name="name" required value="<?php echo e(old('name')); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required value="<?php echo e(old('email')); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Phone</label>
        <input type="text" class="form-control" name="phone" required value="<?php echo e(old('phone')); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Address</label>
        <input type="text" class="form-control" name="address" required value="<?php echo e(old('address')); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" class="form-control" name="password" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <input type="password" class="form-control" name="password_confirmation" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Select Business</label>
        <select class="form-select" name="business_id" required>
            <option value="">-- Select Business --</option>
            <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>"><?php echo e($b->business_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Skill</label>
        <input type="text" class="form-control" name="skill" required value="<?php echo e(old('skill')); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Experience (Years)</label>
        <input type="text" class="form-control" name="experience" required value="<?php echo e(old('experience')); ?>">
    </div>
    <div class="mb-3">
        <label class="form-label">Photo</label>
        <input type="file" class="form-control" name="photo">
    </div>
    <button type="submit" class="btn btn-primary w-100">Register Worker</button>
</form>
<?php /**PATH E:\solar_energy_platform\resources\views/worker/auth/register.blade.php ENDPATH**/ ?>