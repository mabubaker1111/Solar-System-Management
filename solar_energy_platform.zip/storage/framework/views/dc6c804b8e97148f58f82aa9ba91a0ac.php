
<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3 class="mb-4">All Notifications</h3>

    <form action="<?php echo e(route('business.notifications.markAllRead')); ?>" method="POST" class="mb-3">
        <?php echo csrf_field(); ?>
        <button class="btn btn-primary btn-sm">Mark All as Read</button>
    </form>

    <?php if($notifications->count() > 0): ?>
        <div class="list-group shadow-sm rounded-3" style="max-height: 620px; overflow-y: auto; overflow-x: hidden;">
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item d-flex justify-content-between align-items-center <?php echo e($note->read_at ? '' : 'fw-bold'); ?>">
            <span><?php echo e($note->data['message'] ?? 'No message'); ?></span>
            <span class="text-muted ms-2" style="white-space: nowrap;"><?php echo e($note->created_at->diffForHumans()); ?></span>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="d-flex justify-content-center">
        <?php echo e($notifications->links('vendor.pagination.bootstrap-5')); ?>

    </div>

<style>
.list-group::-webkit-scrollbar {
    width: 6px;
}

.list-group::-webkit-scrollbar-thumb {
    background-color: rgba(0,0,0,0.2);
    border-radius: 3px;
}
</style>

    <?php else: ?>
        <p>No notifications found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('business.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/business/notifications/index.blade.php ENDPATH**/ ?>