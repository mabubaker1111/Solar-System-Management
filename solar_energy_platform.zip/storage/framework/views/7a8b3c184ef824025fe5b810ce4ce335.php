
<?php $__env->startSection('title', 'Send Query'); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-4">
    <h3 class="mb-4">Send Query to Business</h3>

    <form action="<?php echo e(route('client.query.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="business_id" value="<?php echo e($business_id); ?>">

        <div class="mb-3">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="5" required><?php echo e(old('message')); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Send</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/client/query/create.blade.php ENDPATH**/ ?>