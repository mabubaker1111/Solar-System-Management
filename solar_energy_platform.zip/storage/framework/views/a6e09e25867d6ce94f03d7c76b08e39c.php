

<?php $__env->startSection('title', 'Worker Shifts'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Worker Shifts</h3>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($workers->isEmpty()): ?>
        <div class="alert alert-warning">
            No workers found.
        </div>
    <?php else: ?>

        
        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card rounded-card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>
                        <i class="fas fa-user me-2"></i>
                        <?php echo e($worker->user->name ?? 'Worker'); ?>

                    </strong>

                    
                    <a href="<?php echo e(route('business.workers.shift.add', $worker->id)); ?>"
                       class="btn btn-sm btn-primary">
                        <i class="fas fa-plus"></i> Add Shift
                    </a>
                </div>

                <div class="card-body p-0">
                    <?php if($worker->shifts->count() == 0): ?>
                        <div class="p-3 text-muted">
                            No shifts added yet.
                        </div>
                    <?php else: ?>
                        <table class="table table-bordered table-striped mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">#</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                    <th width="140">Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $worker->shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($shift->shift_start); ?></td>
                                        <td><?php echo e($shift->shift_end); ?></td>

                                        <td class="d-flex gap-2">

                                            
                                            <a href="<?php echo e(route('business.workers.shift.edit', $shift->id)); ?>"
                                               class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            
                                            <form action="<?php echo e(route('business.workers.shift.delete', $shift->id)); ?>"
                                                  method="POST"
                                                  onsubmit="return confirm('Delete this shift?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit"
                                                        class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('business.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/business/workers/all_shifts.blade.php ENDPATH**/ ?>