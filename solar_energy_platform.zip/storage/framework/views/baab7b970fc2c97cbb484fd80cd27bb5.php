

<?php $__env->startSection('title', 'All Workers'); ?>

<?php $__env->startSection('content'); ?>
<div class="container ">
   <h3 class="mb-4 text-center fw-bold">All Workers</h3>

<div class="table-container boxshadow">
    <table class="responsive-table">
        <caption class="fs-6">All Registered Workers</caption>
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Address</th>
                <th scope="col">Status</th>
                <th scope="col">Registered At</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($worker->id); ?></th>
                <td data-title="Name"><?php echo e($worker->user->name); ?></td>
                <td data-title="Email"><?php echo e($worker->user->email); ?></td>
                <td data-title="Phone"><?php echo e($worker->user->phone); ?></td>
                <td data-title="Address"><?php echo e($worker->user->address); ?></td>
                <td data-title="Status"><?php echo e(ucfirst($worker->status)); ?></td>
                <td data-title="Registered At"><?php echo e($worker->created_at->format('d-M-Y')); ?></td>
                <td data-title="Actions">
                    <?php if($worker->status == 'pending'): ?>
                    <form action="<?php echo e(route('superadmin.worker.approve', $worker->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success btn-sm bi bi-check-circle-fill"></button>
                    </form>

                    <form action="<?php echo e(route('superadmin.worker.reject', $worker->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm bi bi-x-circle-fill"></button>
                    </form>
                    <?php else: ?>
                    <span class="text-muted">No actions</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</div>
<div class="d-flex justify-content-center">
    <?php echo e($workers->links('vendor.pagination.bootstrap-5')); ?>

</div>

<style>
    .boxshadow {
    box-shadow: 1px 1px 10px -2px;
}
/* Table Container Adjusted for Sidebar */
.table-container {
    width: calc(100%);
    overflow-x: auto;
    max-height: 550px;
    padding: 0;
}

/* Scrollbar Styling */
.table-container::-webkit-scrollbar {
    height: 6px;
}
.table-container::-webkit-scrollbar-thumb {
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
}

/* Responsive Table */
.responsive-table {
    width: 120%;
    border-collapse: collapse;
    /* margin-bottom: 1.5em; */
    font-family: sans-serif;
}

.responsive-table caption {
    font-size: 1.2em;
    font-weight: bold;
    margin-bottom: 0.5em;
    text-align: center;
}

.responsive-table th,
.responsive-table td {
    padding: 0.75em 0.5em;
    border: 1px solid rgba(134,188,37,1);
    text-align: center;
    vertical-align: middle;
}

.responsive-table thead th {
    background: linear-gradient( #4e73df, #1cc88a);
    color: white;
}

/* Zebra Striping */
.responsive-table tbody tr:nth-of-type(even) {
    background-color: rgba(0,0,0,.05);
}

/* Actions Button Styling */
.responsive-table td form button,
.responsive-table td span {
    display: inline-block;
    margin: 0;
}

/* Mobile View */
@media (max-width: 768px) {
    .table-container {
        width: 100%;
        margin-left: 0;
    }

    .responsive-table thead {
        position: absolute;
        clip: rect(1px 1px 1px 1px); 
        padding: 0;
        border: 0;
        height: 1px; 
        width: 1px; 
        overflow: hidden;
    }

    .responsive-table tbody,
    .responsive-table tr,
    .responsive-table th,
    .responsive-table td {
        display: block;
        width: 100%;
        text-align: left;
    }

    .responsive-table td[data-title]:before {
        content: attr(data-title);
        font-weight: bold;
        float: left;
    }

    .responsive-table td {
        padding-left: 50%;
        position: relative;
    }

    .responsive-table td[data-title]:before {
        position: absolute;
        left: 0;
        top: 0;
        padding-left: 0.5em;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('superadmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/superadmin/workers/index.blade.php ENDPATH**/ ?>