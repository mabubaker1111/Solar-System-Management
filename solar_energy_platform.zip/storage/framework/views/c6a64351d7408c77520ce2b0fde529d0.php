
<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="card p-4">
    <h3>Notifications</h3>
    <form action="<?php echo e(route('client.notifications.markAllRead')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-success btn-sm mb-3">Mark all as read</button>
    </form>

    <?php if($notifications->count() > 0): ?>
        <ul class="list-group">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <a href="<?php echo e($note->data['link'] ?? '#'); ?>">
                    <?php echo $note->data['message'] ?? 'No message'; ?>

                </a>
                <?php if(!$note->read_at): ?>
                    <span class="badge bg-warning">New</span>
                <?php endif; ?>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <p>No notifications found.</p>
    <?php endif; ?>
</div>
<div class="d-flex justify-content-center">
        <?php echo e($notifications->links('vendor.pagination.bootstrap-5')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/client/notifications.blade.php ENDPATH**/ ?>