
<?php $__env->startSection('title','My Requests'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4" style="height: auto">
    <h3 class="mb-4">My Service Requests</h3>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(isset($requests) && $requests->count()): ?>
    <div class="table-container rounded-card shadow-xlg">
        <table class="responsive-table">
            <caption class="fs-6 fw-bold text-center">Services Requests</caption>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Service</th>
                    <th>Business</th>
                    <th>Worker</th>
                    <th>Status</th>
                    <th>Requested At</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-title="#"> <?php echo e($index + 1); ?> </td>
                    <td data-title="Service"><?php echo e($req->service->name ?? 'N/A'); ?></td>
                    <td data-title="Business"><?php echo e($req->business->business_name ?? 'N/A'); ?></td>
                    <td data-title="Worker">
                        <?php if($req->worker && $req->worker->user): ?>
                            <div><strong><?php echo e($req->worker->user->name); ?></strong></div>
                            <div>Email: <?php echo e($req->worker->user->email ?? '-'); ?></div>
                            <div>Phone: <?php echo e($req->worker->user->phone ?? '-'); ?></div>

                            
                        <?php else: ?>
                            <span class="text-muted">Not assigned</span>
                        <?php endif; ?>
                    </td>
                    <td data-title="Status">
                        <span class="badge 
                            <?php if($req->status === 'pending'): ?> bg-warning
                            <?php elseif($req->status === 'approved'): ?> bg-success
                            <?php elseif($req->status === 'assigned'): ?> bg-info
                            <?php elseif($req->status === 'rejected'): ?> bg-danger
                            <?php else: ?> bg-secondary
                            <?php endif; ?>">
                            <?php echo e(ucfirst($req->status)); ?>

                        </span>
                    </td>
                    <td data-title="Requested At"><?php echo e(\Carbon\Carbon::parse($req->created_at)->format('d M, Y H:i')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <p class="text-muted">You have not sent any requests yet.</p>
    <?php endif; ?>
</div>
<div class="d-flex justify-content-center">
        <?php echo e($requests->links('vendor.pagination.bootstrap-5')); ?>

    </div>

<style>
/* Table Container with scroll */
.table-container {
    max-width: 100%;
    max-height: 800px;
    overflow-x: auto;
    overflow-y: auto;
    border-radius: 0.25rem;
    position: relative;
}

/* Scrollbar */
.table-container::-webkit-scrollbar {
    width: 6px;
    height: 6px;
}
.table-container::-webkit-scrollbar-thumb {
    background-color: rgba(0,0,0,0.2);
    border-radius: 3px;
}

/* Responsive Table */
.responsive-table {
    width: 120%;
    border-collapse: collapse;
}

.responsive-table th,
.responsive-table td {
    padding: 0.75em 0.5em;
    border: 1px solid rgba(134,188,37,1);
    text-align: center;
    vertical-align: middle;
}

/* Sticky Header */
.responsive-table thead th {
    background: linear-gradient(#4e73df, #1cc88a);
    color: white;
    position: sticky;
    top: 0;
    z-index: 2;
}

/* Zebra Striping */
.responsive-table tbody tr:nth-of-type(even) {
    background-color: rgba(0,0,0,.05);
}

/* Mobile view */
@media (max-width: 768px) {
    .responsive-table thead {
        position: absolute;
        clip: rect(1px 1px 1px 1px); 
        height: 1px; 
        width: 1px; 
        overflow: hidden;
    }

    .responsive-table tbody,
    .responsive-table tr,
    .responsive-table td {
        display: block;
        width: 100%;
        text-align: left;
    }

    .responsive-table td[data-title]:before {
        content: attr(data-title);
        font-weight: bold;
        float: left;
    }

    .responsive-table td {
        padding-left: 50%;
        position: relative;
    }

    .responsive-table td[data-title]:before {
        position: absolute;
        left: 0;
        top: 0;
        padding-left: 0.5em;
    }
}

/* Rounded card shadow */
.rounded-card {
    border-radius: 12px;
    box-shadow: 0 4px 14px rgba(0,0,0,0.07);
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/client/request_status.blade.php ENDPATH**/ ?>