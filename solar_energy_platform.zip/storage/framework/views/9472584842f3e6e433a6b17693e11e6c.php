
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="fw-bold mb-3">Welcome, <?php echo e(auth()->user()->name); ?></h3>

<div class="row">
    <div class="col-md-6 mb-3">
        <div class="card p-4 shadow-sm">
            <h4>Browse Businesses</h4>
            <p class="text-muted">Find service providers and send them requests.</p>
            <a href="<?php echo e(route('client.businesses')); ?>" class="btn btn-primary">View Businesses</a>
        </div>
    </div>

    <div class="col-md-6 mb-3">
        <div class="card p-4 shadow-sm">
            <h4>My Requests</h4>
            <p class="text-muted">Track your service request status.</p>
            <a href="<?php echo e(route('client.requests')); ?>" class="btn btn-primary">View Requests</a>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/client/dashboard.blade.php ENDPATH**/ ?>