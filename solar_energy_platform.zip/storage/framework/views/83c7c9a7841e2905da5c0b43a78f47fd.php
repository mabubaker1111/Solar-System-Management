

<?php $__env->startSection('title', 'Client Requests'); ?>

<?php $__env->startSection('content'); ?>
    <h3 class="text-center fw-bold mb-4">Clients Requests</h3>

<div class="table-container boxshadow">
    <table class="responsive-table">
        <caption class="fs-6">Client Service Requests</caption>
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Client Name</th>
                <th scope="col">Service</th>
                <th scope="col">Business</th>
                <th scope="col">Worker</th>
                <th scope="col">Status</th>
                <th scope="col">Requested At</th>
                <th scope="col">Deadline</th>
                <th scope="col">Mark Completed</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($request->id); ?></th>
                <td data-title="Client Name"><?php echo e($request->client->name); ?></td>
                <td data-title="Service"><?php echo e($request->service?->name ?? '-'); ?></td>
                <td data-title="Business"><?php echo e($request->business?->business_name ?? '-'); ?></td>
                <td data-title="Worker"><?php echo e($request->worker?->user?->name ?? '-'); ?></td>
                <td data-title="Status"><?php echo e(ucfirst($request->status)); ?></td>
                <td data-title="Requested At"><?php echo e($request->created_at?->format('d-M-Y') ?? '-'); ?></td>
                <td data-title="Deadline">
                    <?php if($request->deadline): ?>
                        <?php
                            $today = \Carbon\Carbon::today();
                            $deadline = \Carbon\Carbon::parse($request->deadline);
                        ?>
                        <span class="<?php if($deadline->isPast()): ?> text-danger <?php elseif($deadline->diffInDays($today) <= 2): ?> text-warning <?php endif; ?>">
                            <?php echo e($deadline->format('d-M-Y')); ?>

                        </span>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td data-title="Mark Completed">
                    <?php if($request->status != 'completed'): ?>
                        <form method="POST" action="<?php echo e(route('superadmin.request.complete', $request->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success btn-sm">Complete</button>
                        </form>
                    <?php else: ?>
                        <span class="text-success">Completed</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="d-flex justify-content-center">
    <?php echo e($requests->links('vendor.pagination.bootstrap-5')); ?>

</div>

<style>
    .boxshadow {
    box-shadow: 1px 1px 10px -2px;
}
.table-container {
width: 100%;
    max-height: 550px; 
    overflow-y: auto;
    overflow-x: auto; 
    padding:  0;
    border-radius: 0.25rem;
    position: relative;
}

.table-container::-webkit-scrollbar {
    width: 6px;
}
.table-container::-webkit-scrollbar-thumb {
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: 3px;
}

.responsive-table {
    width: 130%;
    border-collapse: collapse;
    font-family: sans-serif;
}

.responsive-table caption {
    font-size: 1.2em;
    font-weight: bold;
    text-align: center;
}

.responsive-table th,
.responsive-table td {
    padding: 0.75em 0.5em;
    border: 1px solid rgba(134,188,37,1);
    text-align: center;
    vertical-align: middle;
}

.responsive-table thead th {
    background: linear-gradient( #4e73df, #1cc88a);
    color: white;
    position: sticky;
    top: 0;
    z-index: 2;
}

.responsive-table tbody tr:nth-of-type(even) {
    background-color: rgba(0,0,0,.05);
}

.responsive-table td form button,
.responsive-table td span {
    display: inline-block;
    margin: 0;
}

@media (max-width: 768px) {
    .table-container {
        width: 100%;
    }

    .responsive-table thead {
        position: absolute;
        clip: rect(1px 1px 1px 1px); 
        padding: 0;
        border: 0;
        height: 1px; 
        width: 1px; 
        overflow: hidden;
    }

    .responsive-table tbody,
    .responsive-table tr,
    .responsive-table th,
    .responsive-table td {
        display: block;
        width: 100%;
        text-align: left;
    }

    .responsive-table td[data-title]:before {
        content: attr(data-title);
        font-weight: bold;
        float: left;
    }

    .responsive-table td {
        padding-left: 50%;
        position: relative;
    }

    .responsive-table td[data-title]:before {
        position: absolute;
        left: 0;
        top: 0;
        padding-left: 0.5em;
    }
}
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('superadmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/superadmin/requests/client.blade.php ENDPATH**/ ?>