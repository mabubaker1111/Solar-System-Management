<div class="card p-4">
    <h3 class="text-center">Login</h3>
    <form action="<?php echo e(route('login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button class="btn btn-primary w-100">Login</button>
        <p class="text-center mt-2">
            No account? <a href="<?php echo e(route('client.register')); ?>">Register Now</a>
        </p>
    </form>
</div><?php /**PATH E:\solar_energy_platform\resources\views/auth/login.blade.php ENDPATH**/ ?>