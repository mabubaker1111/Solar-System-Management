

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="mb-0 fw-bold">Notifications</h3>
        <form action="<?php echo e(route('superadmin.notifications.markAllRead')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-primary">Mark all as read</button>
        </form>
    </div>
    <div class="card-body" style="max-height: 660px; overflow-y: auto;">
        <?php if($notifications->count() > 0): ?>
            <ul class="list-group">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item <?php echo e(is_null($note->read_at) ? 'bg-light' : ''); ?>">
                        <a href="<?php echo e($note->data['link'] ?? '#'); ?>">
                            <?php echo e($note->data['message'] ?? 'No message'); ?>

                        </a>
                        <span class="text-muted float-end" style="font-size: 0.8rem;">
                            <?php echo e($note->created_at->diffForHumans()); ?>

                        </span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="text-muted text-center">No notifications found.</p>
        <?php endif; ?>
    </div>
</div>
<div class="d-flex justify-content-center">
    <?php echo e($notifications->links('vendor.pagination.bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('superadmin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/superadmin/includes/notifications.blade.php ENDPATH**/ ?>