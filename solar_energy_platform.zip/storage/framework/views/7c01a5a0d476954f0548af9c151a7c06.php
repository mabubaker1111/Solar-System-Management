

<?php $__env->startSection('title', 'Client Requests'); ?>

<?php $__env->startSection('content'); ?>
<h3 class="text-center">All Client Request</h3>
<div class="table-container">
    <table class="responsive-table">
        <caption class="fs-6 text-center fw-bold">All Registered Businesses</caption>
        <thead>
            <tr>
                <th>Client Name</th>
                <th>Service</th>
                <th>Status</th>
                <th>Deadline</th>
                <th>Description</th>
                <th>Price</th>
                <th>Assign Worker</th>
                <th>Completed</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td data-title="Client Name"><?php echo e($req->client->name ?? 'Unknown Client'); ?></td>
                <td data-title="Service"><?php echo e($req->service->name ?? 'Unknown Service'); ?></td>

                <td data-title="Status">
                    <?php if($req->status == 'pending'): ?> Pending
                    <?php elseif($req->status == 'approved'): ?> Approved
                    <?php elseif($req->status == 'assigned'): ?> Assigned to <?php echo e($req->worker->user->name ?? 'N/A'); ?>

                    <?php elseif($req->status == 'rejected'): ?> Rejected
                    <?php elseif($req->status == 'completed'): ?> Completed
                    <?php endif; ?>
                </td>

                <td data-title="Deadline">
                    <?php echo e($req->deadline ? \Carbon\Carbon::parse($req->deadline)->format('d-M-Y') : '-'); ?>

                </td>

                <td data-title="Description"><?php echo e($req->notes ?? '-'); ?></td>
                <td data-title="Price"><?php echo e($req->price ?? '-'); ?></td>
                <td data-title="Assign Worker">
                    <?php if($req->status == 'pending' || $req->status == 'approved'): ?>
                    <form method="POST" action="<?php echo e(route('business.assign.worker')); ?>" class="assign-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="request_id" value="<?php echo e($req->id); ?>">

                        <select name="worker_id" class="form-select form-select-sm" required>
                            <option value="">-- Select Worker --</option>
                            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($w->status == 'approved'): ?>
                            <option value="<?php echo e($w->id); ?>"><?php echo e($w->user->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <button type="submit" class="btn btn-primary btn-sm">Assign</button>
                    </form>
                    <?php else: ?>
                    <span class="text-success">Assigned</span>
                    <?php endif; ?>
                </td>

                <td data-title="Completed">
                    <?php if($req->status != 'completed'): ?>
                    <form method="POST" action="<?php echo e(route('business.request.complete', $req->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success btn-sm">Mark</button>
                    </form>
                    <?php else: ?>
                    <span class="text-success fw-bold">Completed</span>
                    <?php endif; ?>
                    <div class="modal fade" id="completeModal<?php echo e($req->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <form action="<?php echo e(route('worker.request.complete', $req->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">

                                    <div class="modal-header">
                                        <h5 class="modal-title">Complete Task</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>

                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <label>Service Name</label>
                                            <input type="text" class="form-control" value="<?php echo e($req->service->name); ?>"
                                                readonly>
                                        </div>

                                        <div class="mb-3">
                                            <label>Full Payment</label>
                                            <input type="number" class="form-control full-payment" name="full_payment"
                                                value="<?php echo e($req->price); ?>" readonly>
                                        </div>

                                        <div class="mb-3">
                                            <label>Quantity</label>
                                            <input type="number" class="form-control quantity" name="quantity" value="1"
                                                min="1">
                                        </div>

                                        <div class="mb-3">
                                            <label>Discount</label>
                                            <input type="number" class="form-control discount" name="discount" value="0"
                                                min="0">
                                        </div>

                                        <div class="mb-3">
                                            <label>Final Amount</label>
                                            <input type="number" class="form-control final-amount" name="final_amount"
                                                readonly>
                                        </div>

                                        <div class="mb-3">
                                            <label>Received Amount</label>
                                            <input type="number" class="form-control received" name="received_amount"
                                                value="0" min="0">
                                        </div>

                                        <div class="mb-3">
                                            <label>Remaining Amount</label>
                                            <input type="number" class="form-control remaining-amount"
                                                name="remaining_amount" readonly>
                                        </div>

                                        <div class="mb-3">
                                            <label>Comment</label>
                                            <textarea class="form-control" name="comment"
                                                placeholder="Optional notes"></textarea>
                                        </div>

                                    </div>

                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                        <button type="button" class="btn btn-secondary"
                                            data-bs-dismiss="modal">Close</button>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">No requests found</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="d-flex justify-content-center">
    <?php echo e($requests->links('vendor.pagination.bootstrap-5')); ?>

</div>
<style>
    .table-container {
        max-height: 550px;
        overflow-y: auto;
        overflow-x: auto;
        width: 100%;
        border-radius: 0.25rem;
        position: relative;
    }

    .table-container::-webkit-scrollbar {
        width: 6px;
        height: 6px;
    }

    .table-container::-webkit-scrollbar-thumb {
        background-color: rgba(0, 0, 0, 0.2);
        border-radius: 3px;
    }

    .responsive-table {
        width: 120%;
        border-collapse: collapse;
        min-width: 900px;
    }

    .responsive-table th,
    .responsive-table td {
        padding: 0.7em;
        border: 1px solid rgba(134, 188, 37, 0.8);
        text-align: center;
        vertical-align: middle;
    }

    .responsive-table thead th {
        background: linear-gradient(#4e73df, #1cc88a);
        color: white;
        position: sticky;
        top: 0;
        z-index: 2;
    }

    .responsive-table tbody tr:nth-child(even) {
        background-color: rgba(0, 0, 0, .05);
    }

    .assign-form {
        display: flex;
        gap: 6px;
        align-items: center;
        justify-content: center;
    }

    @media (max-width: 768px) {
        .responsive-table thead {
            position: absolute;
            clip: rect(1px 1px 1px 1px);
            height: 1px;
            width: 1px;
            overflow: hidden;
        }

        .responsive-table tr,
        .responsive-table td {
            display: block;
            text-align: right;
            position: relative;
        }

        .responsive-table td[data-title]:before {
            content: attr(data-title);
            position: absolute;
            left: 0;
            width: 50%;
            padding-left: 10px;
            font-weight: bold;
            text-align: left;
        }
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('business.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\solar_energy_platform\resources\views/business/requests.blade.php ENDPATH**/ ?>